#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define MANIFEST 24

#define DLG_MAIN                             100
#define DLG_ABOUTDIALOG                      101
#define DLG_HELP_ABOUT                       103
#define IDC_EDTABOUT                         104

#define IDC_Label1     1001 //Min dist
#define IDC_Label2     1002 //Max dist
#define IDC_Label3     1003 //Max AI dist
#define IDC_Label4     1004 //Base Vol
#define IDC_Label5     1005 //Game Type
#define IDC_lblSndName 1006 //No sound

#define IDC_Edit_mindist 1011
#define IDC_Edit_maxdist 1012
#define IDC_Edit_maxaidist 1013
#define IDC_Edit_basevol 1014
#define IDC_cbSndType    1015 //cbSndType: TComboBox

#define IDC_Load         1020 //Load
#define IDC_Update       1021 //Update

#define IDC_StatusBar    1025
