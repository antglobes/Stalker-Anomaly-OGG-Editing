/*******************************************************************************
��� ���� S.T.A.L.K.E.R (���� ���������) �������� � � ���������
��������� ��� "��������������" ������ "������" ������������ � ������ ogg
�.�. ����������� ������ � log ������ ����:
! Invalid ogg-comment version, file:  \s.t.a.l.k.e.r. shadow of chernobyl\gamedata\sounds\ambient\rnd_outdoor\rnd_krik9.ogg
! Missing ogg-comment, file:  \s.t.a.l.k.e.r. shadow of chernobyl\gamedata\sounds\characters_voice\human_01\freedom\fight\hit\hit_1.ogg

create by Tervel aka ������� http://www.amk-team.ru/forum/index.php?showuser=1499
http://tervel.livejournal.com/

���������� � Code::Blocks 13.12
���������� � mingw32-gcc version 4.8.1 (GCC)

������� �� ����:
xchatx � Bane_v2 - http://www.gamefaqs.com/boards/540331-stalker-shadow-of-chernobyl/43002734
loxotron - http://stalkerin.gameru.net/wiki/index.php?title=OGG_���������������
AMK Team & ���, ������� - http://stalkerin.gameru.net/wiki/index.php?title=Sound_Editor
Swerg � VEG - http://vorbis.org.ru/forum/viewtopic.php?t=223
ytrfamli - http://forum.xentax.com/viewtopic.php?f=17&t=5314

�������� ������� �� ��������� "��������� ����������� ������������ � Ogg-������"
Sin! � Shoker : http://www.amk-team.ru/forum/index.php?showtopic=1481&p=797305
�������� !!!:
��������� ����������� ������������ � Ogg-������ (OGGEditor.exe) �� ����������/�����������
����������, ���� � ogg ������ vender �������� �� "Xiph.Org libVorbis I 20050304"

����� ������������� �� ��������� "������ ����, ����������� � OGM ������"
George Shuklin -  http://shounen.ru/docs/ogm/ogm.shtml

�� ��������� ���������� �������� crc32, ���������� ��� OGM .
http://www.csee.usf.edu/~christen/tools/crc32.c

��������� ������� nihilant �� fixoggcs.exe
� Ross Levis �� VorbisComment.exe - http://winvorbis.stationplaylist.com
*******************************************************************************/
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <time.h>
#include <string.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <fcntl.h>

#define _test_ printf //���� �������
#define TRUE 1
#define FALSE 0


#define OUT_L(...) output_log(TRUE,flog,__VA_ARGS__)
#define OUT_L0(...) output_log(FALSE,flog,__VA_ARGS__)

/*******************************************************************************
��������������� ���������� ���������� � ��������
*******************************************************************************/
char config_file[255];
char inp_file[255];
char inp_Folder[255];
char log_file[255];
char path[255];

char del_file=0;
char cor_file=0;
char cor_alws=0;
char info_ogg=0;
char bat_log=0;

//unsigned char ogg_corr[24]; //HEX DUMP ogg-comment
  unsigned char ogg_corr[]={0x03,0x00,0x00,0x00,0x00,0x00,0x80,0x3F,0x00,0x00,0xC0,0x41,0x00,0x00,0x80,0x3F,0x80,0x00,0x00,0x08,0x00,0x00,0xC0,0x41};

FILE   *flog=NULL;

time_t log_time;
struct tm * tml;

const char mod_ver[]  = "S.T.A.L.K.E.R OGG Comment Fixer v.0.07 build 2015.0204";

const char help_msg[] = "oggcommentfix.exe - fix comment in ogg file(s)\n"
      "Usage: oggcommentfix -<command><value>...--<command>=<value>...[file.ogg]\n\n"
      "Commands:\n"
//      "-i,--inp_file\t\t- input file (max len 255);\n"
      "-l,--log_file\t\t- enable log file (max len 255) default: oggcommentfix.log;\n"
//      "-B,--bat\t\t- create CMD/BAT file;\n"
      "-C,--correct\t\t- correct ogg comment (to default);\n"
      "-Cq;mid;mad;maid;bv;gt , --correct=q;mid;mad;maid;bv;gt -\n"
      " correct ogg comment to value Quality;MinDist;MaxDist;MaxAIDist;BaseVolume;GameTypes;\n"
      "-CHxxxxxxxxxxxxxxxx , --correcthex=xxxxxxxxxxxxxxxx -\n"
      " correct ogg comment to xxxxxxx value (xx - HEX dump 48 chars/24 Bytes);\n"
      "-D,--delete\t\t- delete file(s) if ogg comment correct !!!;\n"
      "-F,--folder\t\t- scan files in folder (max len 255);\n"
      "-I,--info\t\t- output comment info;\n"
      "-IH\t\t\t- output comment info in HEX;\n"
      "-Y,--yes\t\t- correcting ogg comment always;\n"

      "-h,--help\t\t- show this screen.\n\n";

/*******************************************************************************
*******************************************************************************/
void show_help()
{
  printf("%s\n",mod_ver);
  printf(help_msg);
  exit (0);
}

/******************************************
******************************************/
void show_error_cmd(char * err)
{
  printf("%s\n",mod_ver);
  printf("ERROR:UNKNOWN COMMAND: %s\n",err);
  printf("TRY '-h' FOR HELP\n");
}

/******************************************
******************************************/
void lower_string(char * str)
{
    int i;
  for(i = 0; i < strlen(str); i++)
    if(isupper(str[i]))
          str[i] = tolower(str[i]);
}

/*******************************************************************************
*******************************************************************************/
int parse_cmd(int argc, char* argv[])
{
  int i;
  char * cmd;
  char Type [256];
  char Meaning [256];

  for(i = 1; i < argc; i++)
  {
    cmd = argv[i]+2;

//_test_("i:%2d %c = %s [%d]\n",i,argv[i][1],cmd,strlen(cmd));

    switch(argv[i][0])
    {
      case '-':
        switch(argv[i][1])
        {

          case 'f':
            strncpy(config_file,cmd,sizeof(config_file)-1);
            printf("Config file: %s\n",config_file);
            if(parse_config_file(config_file)==-1)
            {
              printf("Config file %s not found\n",config_file);
              return -1;
            }
          break;

//          case 'i':
//            strncpy(inp_file,cmd,sizeof(inp_file)-1);
//          break;

          case 'l':
            if (strlen(cmd))
              strncpy(log_file,cmd,sizeof(inp_file)-1);
            else
                sprintf (log_file,"oggcommentfix.log");
          break;

          case 'F':
            if (strlen(cmd))
              strncpy(inp_Folder,cmd,sizeof(inp_Folder)-1);
            else
                sprintf (inp_Folder,".");
          break;

          case 'B':
            bat_log=1;
          break;

          case 'C':
            cor_file=1;
            if (argv[i][2])
            { cor_file=2;
              if (argv[i][2]=='H')
              { int j;
                char tmp[3];
                if (strlen(argv[i])!=51)
                {
                  //printf("strlen -CH: %d\n",strlen(argv[i])); //51
                  printf("HEX DUMP Error - must be 24 byte (48 Chars)\n");
                  return -1;
                }
                tmp[0]='\0'; tmp[1]='\0'; tmp[2]='\0';
                for (j=0; j<48 ;j++)
                {
                  tmp[j%2]=argv[i][j+3];
                  if (j%2)
                  {
                    ogg_corr[j/2]=strtol(tmp,0,16);
                    tmp[0]='\0'; tmp[1]='\0';

                  }
                }
//for (j=0; j<24 ;j++) _test_("%02X ",ogg_corr[j]); _test_("\n");
              }
              else
              {
                struct {
                int   i_quality;
                float f_mindist,
                      f_maxdist,
                      f_maxaidist,
                      f_basevol;
                int   i_sndtype;
                } ct;
                //_test_(" -C: [%d] %s\n",strlen(argv[i]),argv[i]);
                sscanf(argv[i],"-C%d;%f;%f;%f;%f;%d",&ct.i_quality,&ct.f_mindist,&ct.f_maxdist,&ct.f_maxaidist,&ct.f_basevol,&ct.i_sndtype);
                //_test_("Q: %-d MinD: %-4.2f MaxD: %-4.2f MaxAID: %-4.2f BsVl: %-4.2f | %d\n",ct.i_quality,ct.f_mindist,ct.f_maxdist,ct.f_maxaidist,ct.f_basevol,ct.i_sndtype);
                memcpy(&ogg_corr   ,&ct,24);
              }

            }

          break;

          case 'D':
            del_file=1;
          break;

          case 'I':
            info_ogg=1;
            if (argv[i][2]=='H') info_ogg=2;

          break;

          case 'Y':
            cor_alws=1;
          break;

          case '?':
          case 'h':
            show_help();
            return 1;
          break;

          case '-':
          {
            if(sscanf(cmd,"%[^=' '] =%s\n",Type,Meaning) != 0)
            {
              lower_string(Type);
              if     (!strcmp(Type,"cfg_file"))   { strncpy(config_file,Meaning,sizeof(config_file)-1);
              	                                    if(parse_config_file(config_file)==-1)
//              	                                    {my_log(APPL_LOG,"Config file %s not found",config_file);return -1;}
              	                                    break;}

              //else if(!strcmp(Type,"inp_file"))  { strncpy(inp_file,Meaning,sizeof(inp_file)-1);break;}
              else if(!strcmp(Type,"log_file"))  { strncpy(log_file,Meaning,sizeof(log_file)-1);break;}
              else if(!strcmp(Type,"folder"))    { strncpy(inp_Folder,Meaning,sizeof(inp_Folder)-1);break;}
              else if(!strcmp(Type,"correct"))
              { cor_file=1;
                if (strlen(cmd)>7)
                  if (strlen(cmd)<19)
                  {
                    printf("Error in command: %s\n",argv[i]);
                    return -1;
                  }
                  else
                  {
                    cor_file=2;
                    struct {
                    int   i_quality;
                    float f_mindist,
                          f_maxdist,
                          f_maxaidist,
                          f_basevol;
                    int   i_sndtype;
                    } ct;
                    //_test_(" -C: [%d] %s\n",strlen(argv[i]),argv[i]);
                    sscanf(argv[i],"-C%d;%f;%f;%f;%f;%d",&ct.i_quality,&ct.f_mindist,&ct.f_maxdist,&ct.f_maxaidist,&ct.f_basevol,&ct.i_sndtype);
                    //_test_("Q: %-d MinD: %-4.2f MaxD: %-4.2f MaxAID: %-4.2f BsVl: %-4.2f | %d\n",ct.i_quality,ct.f_mindist,ct.f_maxdist,ct.f_maxaidist,ct.f_basevol,ct.i_sndtype);
                    memcpy(&ogg_corr,&ct,24);
                  }
                break;
              }
              else if(!strcmp(Type,"correcthex"))
              {
                int j;
                char tmp[3];

                cor_file=2;
                if (strlen(Meaning)!=48)
                {
                  printf("HEX DUMP Error - must be 24 byte (48 Chars)\n");
                  return -1;
                }
                tmp[0]='\0'; tmp[1]='\0'; tmp[2]='\0';
                for (j=0; j<48 ;j++)
                {
                  tmp[j%2]=Meaning[j];
                  if (j%2)
                  {
                    ogg_corr[j/2]=strtol(tmp,0,16);
                    tmp[0]='\0'; tmp[1]='\0';

                  }
                }
//for (j=0; j<24 ;j++) _test_("%02X ",ogg_corr[j]); _test_("\n");

                _test_("strlen -correcthex: %d\n",strlen(Meaning));
                break;
              }
              else if(!strcmp(Type,"bat"))       { bat_log=1;break;}
              else if(!strcmp(Type,"delete"))    { del_file=1;break;}
              else if(!strcmp(Type,"info"))      { info_ogg=1;break;}
              else if(!strcmp(Type,"yes"))       { cor_alws=1;break;}
              else if(!strcmp(Type,"help"))      {show_help();return -1;}
              else
              {
                show_error_cmd(argv[i]);
                printf("Error unknown command - %s\n",argv[i]);
                return -1;
              }
            }
            else
            {
              show_error_cmd(argv[i]);
              printf("Error unknown command - %s\n",argv[i]);
              return -1;
            }
          }

          default:
            show_error_cmd(argv[i]);
            printf("Error unknown command - %s\n",argv[i]);
            return -1;
        }
      break;

      default: //������� ��� ��� ������� ����
//        show_error_cmd(argv[i]);
            strncpy(inp_file,argv[i],sizeof(inp_file)-1);
        //return -1;
    }
  }

  return 0;
}

/*******************************************************************************
*******************************************************************************/
int parse_config_file(char* fname)
{
  char Type [256];
  char Meaning [256];
  FILE* fpr1;

  if ((fpr1=fopen(fname,"r")) == NULL)
  {   printf("Config file %s not found.\n",fname);
      return -1;
  }

//  printf("Parse Config file %s.\n",fname);

  while (fscanf (fpr1,"%[^ \n\r='] = %[^ \n\r=']\n",Type,Meaning) != EOF)
  {
    lower_string(Type);
//    printf("line after lower '%s' = '%s'.\n",Type,Meaning);
         if(!strcmp(Type,"inp_file"))  { strncpy(inp_file, Meaning, sizeof(inp_file)-1);}
    else if(!strcmp(Type,"log_file"))  { strncpy(log_file, Meaning, sizeof(log_file)-1);}
//    else if(!strcmp(Type,"out_file"))  { strncpy(out_file, Meaning, sizeof(out_file)-1);}
    else if(!strcmp(Type,"help"))       {show_help();return -1;}
  }

//  printf("Stop parse Config file %s.\n",fname);

  fclose(fpr1);

  return 0;
}

/******************************************
 INIT variables to default
******************************************/
void init_to_defaults()
{

  memset(config_file,   0,sizeof(config_file)-1);
  memset(inp_file,      0,sizeof(config_file)-1);
  memset(log_file,      0,sizeof(log_file)-1);
  memset(inp_Folder,    0,sizeof(inp_Folder)-1);

}

/******************************************

******************************************/
static void output_log(char mod, FILE * fp, char * format,...)
{
   va_list ap;

   va_start(ap, format);
   if (mod)  vprintf(format,ap);
   if (fp!=NULL)
   {
     vfprintf(fp,format,ap);
   }
   va_end(ap);
  return;
}

/*******************************************************************************
*******************************************************************************/
int get_ogg_info(char* fname,char mod)
{ //mod = 0 - ������ STALKER comment
  //mod = 1 - + ��� ����
  //mod = 2 - + ��� ���� HEX
  //mod = 10 - ������������ �� "�������������", ��� ������ ����
  long  lSize; //size of inp file
  int  i,
       j,
        read_ogg_h,
        ogg_vendor_len,
        ogg_comment_cnt,
        ogg_comment_len,
        i_sndtype,
        i_quality,
        ret;
  float //stlk_quality,
        f_mindist,
        f_maxdist,
        f_maxaidist,
        f_basevol;
  char  //txt_quality[16],
        //txt_mindist[16],
        //txt_maxdist[16],
        //txt_maxaidist[16],
        txt_sndtype[16],
        txt_basevol[30];

  unsigned char ogg_h[255];
  char ogg_vendor[100];
  FILE* fin;

  ret=0; //����������� ����, ����� �������������/���������.

   // open the input file for read
   fin = fopen(fname, "rb");
   if(fin == NULL)
   {
      printf("Cant open input file %s\n",fname);
     	return (-1);
   }

  fseek (fin , 0 , SEEK_END);
  lSize = ftell (fin);
  rewind (fin);
  if (mod < 10)
  {
    //printf("file:%s size: %ld \n" ,fname,lSize);
    OUT_L("file:%s size: %ld \n" ,fname,lSize);
  }

  if (lSize<255)
   {
      printf("Very small file\n",fname);
     	return (-2);
   }

  memset(&ogg_h, 0, sizeof(ogg_h));
  memset(&ogg_vendor, 0, sizeof(ogg_vendor));
  memset(&txt_sndtype, 0, sizeof(txt_sndtype));


  read_ogg_h = fread(ogg_h, 255, 1, fin); //������ ������ 255 ����� �� �����

//OggS
  if ((ogg_h[0]!='O') || (ogg_h[1]!='g') || (ogg_h[2]!='g') || (ogg_h[3]!='S'))
   {
      //printf("Incorrect OGG Header\n",fname);
      OUT_L("Incorrect OGG Header\n",fname);
     	return (-3);
   }

  i = 3;
  while(i<200)
  {
    if ((ogg_h[i]==0x03)  &&
        (ogg_h[i+1]=='v') &&
        (ogg_h[i+2]=='o') &&
        (ogg_h[i+3]=='r') &&
        (ogg_h[i+4]=='b') &&
        (ogg_h[i+5]=='i') &&
        (ogg_h[i+6]=='s')
       )
    {
    //@vorbis found
      break;
    }
    i++;
  }

  if (i>200)
   {
      //printf("OGG Vendor not found\n",fname);
      OUT_L("OGG Vendor not found\n",fname);
     	return (-4);
   }
  ret=1; //vendor tag exists
  i+=7;
  memcpy(&ogg_vendor_len,ogg_h+i,sizeof(ogg_vendor_len));
//_test_("seek vendor len:%02X , len: %04X (%d) \n",i,ogg_vendor_len,ogg_vendor_len);
  i+=4;
//_test_("seek vendor:%02X\n",i);
  for(j = 0; j < ogg_vendor_len; j++) ogg_vendor[j]=ogg_h[i+j];
  if (mod < 10)
  {
    //if (mod) printf("vendor: %s\n",ogg_vendor);
    if (mod) OUT_L("vendor: %s\n",ogg_vendor);
  }
  if (!strncmp(ogg_vendor,"Xiph.Org libVorbis I 20050304",29))
  {
    ret=2;
  }
  else
  { if (mod < 10)
    {
      //if (mod) printf("Warning: !!! File can't edit from OGGEditor.exe\n");
      if (mod) OUT_L("Warning: !!! File can't edit from OGGEditor.exe\n");
    }
  }

  i+=ogg_vendor_len;
//_test_("seek comment:%02X\n",i);

  memcpy(&ogg_comment_cnt,ogg_h+i,sizeof(ogg_comment_cnt));
  memcpy(&ogg_comment_len,ogg_h+i+4,sizeof(ogg_comment_len));
  i+=8;

  if ((ogg_comment_cnt==1) && (ogg_comment_len==24)) //������������ 1 � ��� ������=24 ����� - �������� ��� ��������������
  {  if (ret==2)
        ret=90;
      else
        ret=3;

    if (mod < 10)
    {
      //if (mod==2) {printf("comment:"); for(j = i; j < i+24; j++) printf(" %02X",ogg_h[j]); printf("\n");}
      if (mod==2) {OUT_L("comment:"); for(j = i; j < i+24; j++) OUT_L(" %02X",ogg_h[j]); OUT_L("\n");}
    }


//_test_("%02X %02X %02X %02X \n",ogg_h[i],ogg_h[i+1],ogg_h[i+2],ogg_h[i+3]);
     memcpy(&i_quality,ogg_h+i,4); i+=4;
//_test_("%02X %02X %02X %02X \n",ogg_h[i],ogg_h[i+1],ogg_h[i+2],ogg_h[i+3]);
     memcpy(&f_mindist,ogg_h+i,4); i+=4;
//_test_("%02X %02X %02X %02X \n",ogg_h[i],ogg_h[i+1],ogg_h[i+2],ogg_h[i+3]);
     memcpy(&f_maxdist,ogg_h+i,4); i+=4;
//_test_("%02X %02X %02X %02X \n",ogg_h[i],ogg_h[i+1],ogg_h[i+2],ogg_h[i+3]);
     memcpy(&f_basevol,ogg_h+i,4); i+=4;
//_test_("%02X %02X %02X %02X \n",ogg_h[i],ogg_h[i+1],ogg_h[i+2],ogg_h[i+3]);
     memcpy(&i_sndtype,ogg_h+i,4); i+=4;
//_test_("%02X %02X %02X %02X \n",ogg_h[i],ogg_h[i+1],ogg_h[i+2],ogg_h[i+3]);
     memcpy(&f_maxaidist,ogg_h+i,4); i+=4;
//_test_("seek: %#X , MaxAIdist: %#X (%f) \n",i,stlk_maxaidist,stlk_maxaidist);

     switch(i_sndtype)
     {
        case 134217856:
                  strcpy(txt_sndtype,"World ambient");
              break;
        case 134217984:
                  strcpy(txt_sndtype,"Object exploding");
              break;
        case 134218240:
                  strcpy(txt_sndtype,"Object colliding");
              break;
        case 134218752:
                  strcpy(txt_sndtype,"Object breaking");
              break;
        case 268437504:
                  strcpy(txt_sndtype,"Anomaly idle");
              break;
        case 536875008:
                  strcpy(txt_sndtype,"NPC eating");
              break;
        case 536879104:
                  strcpy(txt_sndtype,"NPC attacking");
              break;
        case 536887296:
                  strcpy(txt_sndtype,"NPC talking");
              break;
        case 536903680:
                  strcpy(txt_sndtype,"NPC step");
              break;
        case 536936448:
                  strcpy(txt_sndtype,"NPC injuring");
              break;
        case 537001984:
                  strcpy(txt_sndtype,"NPC dying");
              break;
        case 1077936128:
                  strcpy(txt_sndtype,"Item using");
              break;
        case 1082130432:
                  strcpy(txt_sndtype,"Item taking");
              break;
        case 1090519040:
                  strcpy(txt_sndtype,"Item hiding");
              break;
        case 1107296256:
                  strcpy(txt_sndtype,"Item dropping");
              break;
        case 1140850688:
                  strcpy(txt_sndtype,"Item picking up");
              break;
        case 2147745792:
                  strcpy(txt_sndtype,"weapon recharging");
              break;
        case 2148007936:
                  strcpy(txt_sndtype,"Weapon bullet hit");
              break;
        case 2148532224:
                  strcpy(txt_sndtype,"Weapon empty clicking");
              break;
        case 2149580800:
                  strcpy(txt_sndtype,"Weapon shooting");
              break;

        default:
                  strcpy(txt_sndtype,"undefined");
              break;
     }

     if (i_quality==3) //���� �� �������
     {
       ret+=2;
     }
     else
     { if (mod < 10)
       {
         //printf("Warning! Not legal ogg-comment !!!\n");
         OUT_L("Warning! Not legal ogg-comment !!!\n");
       }
     }
     if (mod < 10)
     {
       //printf("Q: %-6s MinD: %-6s MaxD: %-6s MaxAID: %-6s BsVl: %-3s | %s\n",txt_quality,txt_mindist,txt_maxdist,txt_maxaidist,txt_basevol,txt_sndtype);
       //printf("Q: %-4.2f MinD: %-4.2f MaxD: %-4.2f MaxAID: %-4.2f BsVl: %-4.2f | %s\n",stlk_quality,stlk_mindist,stlk_maxdist,stlk_maxaidist,stlk_basevol,txt_sndtype);
       //OUT_L ("Q: %-6s MinD: %-6s MaxD: %-6s MaxAID: %-6s BsVl: %-3s | %s\n",txt_quality,txt_mindist,txt_maxdist,txt_maxaidist,txt_basevol,txt_sndtype);
       printf("Q: %-d MinD: %-4.2f MaxD: %-4.2f MaxAID: %-4.2f BsVl: %-4.2f | %s\n",i_quality,f_mindist,f_maxdist,f_maxaidist,f_basevol,txt_sndtype);
       OUT_L0("Q: %-d MinD: %-6.4f MaxD: %-6.4f MaxAID: %-6.4f BsVl: %-6.4f | %s\n",i_quality,f_mindist,f_maxdist,f_maxaidist,f_basevol,txt_sndtype);

     }
   }
   else
   {
     if (mod < 10)
     {
       //printf("No ogg-comment or invalid version.\n");
       OUT_L("No ogg-comment or invalid version.\n");
     }
   }

  if (fin!=NULL) fclose(fin);
  return ret;
}

/*******************************************************************************
*******************************************************************************/
int correct_ogg_info(char* fname,char mod)
{ //mod = 0 -

  //return 1 - good
  //return <>1 - bad

  long  lSize; //size of inp file
  int  i,
       j,
        read_ogg_h,
        ogg_vendor_len,
        ogg_comment_cnt,
        ogg_comment_len,
        stlk_id,
        stlk_sndtype,
        ret;
//  float stlk_mindist,
//        stlk_maxdist,
//        stlk_maxaidist,
//        stlk_basevol;
//char  txt_sndtype[16],
//        txt_mindist[16],
//        txt_maxdist[16],
//        txt_maxaidist[16],
//        txt_basevol[30];

  unsigned char ogg_h[255];
  char ogg_vendor[100];
  FILE* fin;

  ret=0; //���� ��� ������ �� ��������.

   // open the input file for read
   fin = fopen(fname, "rb+");
   if(fin == NULL)
   {
      printf("Cant open input file %s\n",fname);
     	return (-1);
   }

  memset(&ogg_h, 0, sizeof(ogg_h));
  memset(&ogg_vendor, 0, sizeof(ogg_vendor));
//  memset(&txt_sndtype, 0, sizeof(txt_sndtype));


  read_ogg_h = fread(ogg_h, 255, 1, fin); //������ ������ 255 ����� �� �����
//OggS
  if ((ogg_h[0]!='O') || (ogg_h[1]!='g') || (ogg_h[2]!='g') || (ogg_h[3]!='S'))
   {
      //printf("Incorrect OGG Header\n");
      OUT_L("Incorrect OGG Header\n");
     	return (-3);
   }

  i = 3;
  while(i<200)
  {
    if ((ogg_h[i]==0x03)  &&
        (ogg_h[i+1]=='v') &&
        (ogg_h[i+2]=='o') &&
        (ogg_h[i+3]=='r') &&
        (ogg_h[i+4]=='b') &&
        (ogg_h[i+5]=='i') &&
        (ogg_h[i+6]=='s')
       )
    {
    //@vorbis found
      break;
    }
    i++;
  }

  if (i>200)
   {
      //printf("OGG Vendor not found\n",fname);
      OUT_L("OGG Vendor not found\n");
     	return (-4);
   }
  ret=1; //vendor tag exists
  i+=7;
  memcpy(&ogg_vendor_len,ogg_h+i,sizeof(ogg_vendor_len));
//_test_("seek vendor len:%02X , len: %04X (%d) \n",i,ogg_vendor_len,ogg_vendor_len);
  i+=4;
//_test_("seek vendor:%02X\n",i);
  for(j = 0; j < ogg_vendor_len; j++) ogg_vendor[j]=ogg_h[i+j];

  i+=ogg_vendor_len;
//_test_("seek comment:%02X\n",i);

  memcpy(&ogg_comment_cnt,ogg_h+i,sizeof(ogg_comment_cnt));
  memcpy(&ogg_comment_len,ogg_h+i+4,sizeof(ogg_comment_len));
  i+=8;
//_test_("seek comment:%02X L:%d\n",i,__LINE__);

  if ((ogg_comment_cnt==1) && (ogg_comment_len==24)) //������������ 1 � ��� ������=24 ����� - �������� ��� ��������������
  {

    ret=fseek (fin , i ,SEEK_SET);
//_test_("seek ret:%d L:%d\n",ret,__LINE__);
    ret=fwrite(ogg_corr, 1, 24, fin);
//_test_("writ ret:%d L:%d\n",ret,__LINE__);
    if (ret==24)
      ret=1;
    else
      ret=0;
//_test_("L:%d\n",__LINE__);

  }
   else
   {
//_test_("L:%d\n",__LINE__);
       //printf("No ogg-comment or invalid version.\n");
       OUT_L("No ogg-comment or invalid version.\n");
       ret=-1;
   }

//_test_("L:%d\n",__LINE__);
  if (fin!=NULL) fclose(fin);
  return ret;
}


/*******************************************************************************
*******************************************************************************/
int one_ogg_file(char* fname)
{
   int ogg_status=0;
   int ret=0;
   char txt_exec[400];

   ogg_status=get_ogg_info(fname,info_ogg);

   if (((ogg_status==5) || (ogg_status==92)) && (!cor_alws))
   {
      if (del_file)
      {
        if(remove(fname) == -1)
        {
          //printf("Error in deleting a file.\n");
          OUT_L("Error in deleting a file.\n");
        }
        else
        {
          //printf("File deleted.\n");
          OUT_L("File deleted.\n");
        }

      }
      ret=0;
   }
   else
   if (cor_file)
   {
     if (( (ogg_status>=0) && (ogg_status<3) ) || (ogg_status==90))
     {

       oggnav( fname,2);

       ogg_status=get_ogg_info(fname,10);
//      if (ogg_status<99) printf("Warning: !!! File can't edit from OGGEditor.exe\n");
       if ((ogg_status==5) || (ogg_status==92))
       {
         //printf("Correct ogg-comment completed.\n");
         OUT_L("Correct ogg-comment completed.\n");
         return 1;
       }

     }

     if ((ogg_status==3) || (ogg_status==90) || (cor_alws))
     {
        ogg_status=correct_ogg_info(fname,0);
//_test_("ogg_correct: %d\n",ogg_status);

        oggnav( fname,1);

        ogg_status=get_ogg_info(fname,info_ogg);
//_test_("ogg_correct: %d\n",ogg_status);
       if ((ogg_status==5) || (ogg_status==92))
       {
         //printf("Correct ogg-comment completed.\n");
         OUT_L("Correct ogg-comment completed.\n");
         ret=1;
       }
       else
       {
         //printf("Error, when correct ogg-comment.\n");
         OUT_L("Error, when correct ogg-comment.\n");
       }
     }
     else
     {
       if ((ogg_status==5) || (ogg_status==92))
       {
         //printf("Already correct ogg-comment.\n");
         OUT_L("Already correct ogg-comment.\n");
         ret=2;
       }
       else
       {
         //printf("Can't correct ogg-comment.\n");
         OUT_L("Can't correct ogg-comment.\n");
       }
     }

   }
   return ret;
}

/*******************************************************************************
scandir - ������� �� ���������
tnx http://www.johnloomis.org/ece537/notes/Files/Examples/printdir.html
*******************************************************************************/
void scandir(char *dir)
{
    DIR *dp;
    struct dirent *entry;
    struct stat statbuf;
    char fname[255];
    //int spaces = depth*2;

    if((dp = opendir(dir)) == NULL) {
        fprintf(stderr,"cannot open directory: %s\n", dir);
        return;
    }
    chdir(dir);
    while((entry = readdir(dp)) != NULL) {
        stat(entry->d_name,&statbuf);
        if(S_ISDIR(statbuf.st_mode)) {
            /* Found a directory, but ignore . and .. */
            if(strcmp(".",entry->d_name) == 0 ||
                strcmp("..",entry->d_name) == 0)
                continue;
            //getcwd(path, 255); printf("%s\\%s /\n",path,entry->d_name);
            /* Recurse at a new indent level */
            scandir(entry->d_name);
        }
        else
        {
            getcwd(path, 255);
            sprintf(fname,"%s\\%s",path,entry->d_name);
            //printf("%s\n",fname);
            if (!strncasecmp(".ogg",fname+(strlen(fname)-4),4))
            {
              //printf("IS OGG\n");
              one_ogg_file(fname);
            }

        }
    }
    chdir("..");
    closedir(dp);
}

/******************************************
 MAIN
******************************************/
int main(int argc, char ** argv)
{
   int arg,j;
   int ret=0;

   time(&log_time);
   tml = localtime(&log_time);

   if(argc < 2)
   {
     printf("%s\n",mod_ver);
     printf("ERROR:USAGE ERROR\n");
     printf("TRY '-h' FOR HELP\n");
     return 1;
   }

   init_to_defaults();

   if((arg=parse_cmd(argc,argv))==-1)
   {
     printf("ERROR: wrong arguments.\n");
     show_help();
     sleep(1);
     exit(-1);
  }

  getcwd(path, 255);

    if (!(inp_file[0]) && !(inp_Folder[0]))
    {
      printf("No input File or Folder\n",log_file);
     	exit (-4);
    }

    if ((inp_file[0]) && (inp_Folder[0]))
    {
      printf("CONFLICT. File & Folder is set.\n",log_file);
     	exit (-5);
    }

    if (del_file)
    {
      char reply;

        fputs("ATTENTION! All good file(s) with ogg-comment will be deleted! (y/n)> ", stdout);
        fflush(stdout);
        reply = getchar();
        do { int ch; while( (ch = getchar()) != '\n' && ch != EOF ); } while(0);

       //printf("answer:%c",toupper(reply));
       if (toupper(reply)!='Y') exit(0);
    }

    if (log_file[0])
    {
      flog = fopen(log_file, "w");
      if (flog==NULL)
      { printf("Can't open log file %s\n",log_file);
      	exit (-3);
      }
      OUT_L0("Start: %04d%02d%02d %02d:%02d:%02d\n\n",1900+tml->tm_year,1+tml->tm_mon,tml->tm_mday,tml->tm_hour, tml->tm_min, tml->tm_sec);
    }

    if (inp_Folder[0])
    {
       scandir(inp_Folder);
    }
    else
      if (!inp_file[0])
        printf("No input file\n",inp_file);
      else
      { ret=one_ogg_file(inp_file);
      }


/********* END *********/
    time(&log_time);
    tml = localtime(&log_time);

    if (flog!=NULL)
    {

      OUT_L0("\nEnd: %04d%02d%02d %02d:%02d:%02d\n",1900+tml->tm_year,1+tml->tm_mon,tml->tm_mday,tml->tm_hour, tml->tm_min, tml->tm_sec);
      fclose(flog);

    }

    return 0;
}
